self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c9ad3a0babebd2c1e1ee0ed2fd35e125",
    "url": "/resume/index.html"
  },
  {
    "revision": "b027d9dfc9f733cf5600",
    "url": "/resume/static/css/main.710abd55.chunk.css"
  },
  {
    "revision": "8d026fe1b422f577fc2a",
    "url": "/resume/static/js/2.ce37c45a.chunk.js"
  },
  {
    "revision": "b027d9dfc9f733cf5600",
    "url": "/resume/static/js/main.4297cf93.chunk.js"
  },
  {
    "revision": "9db945c116828596ace9",
    "url": "/resume/static/js/runtime-main.937885ad.js"
  },
  {
    "revision": "319a0e92aba359c9f87c1f6fe2f48233",
    "url": "/resume/static/media/AdobeNaskh-Medium.319a0e92.otf"
  },
  {
    "revision": "fcba756ee621c9a59085ba2e7b10e2b0",
    "url": "/resume/static/media/FiraSans-Bold.fcba756e.otf"
  },
  {
    "revision": "53d0609ce9355975ff1aaa6b20bab95b",
    "url": "/resume/static/media/FiraSans-ExtraLight.53d0609c.otf"
  },
  {
    "revision": "020f40e1d993eebe994bf90a060f9dde",
    "url": "/resume/static/media/FiraSans-Light.020f40e1.otf"
  },
  {
    "revision": "f255f5eaf67ade842bae0d10ec988b81",
    "url": "/resume/static/media/FiraSans-Medium.f255f5ea.otf"
  },
  {
    "revision": "d95cbc6b34b438262a5b42ae58bae701",
    "url": "/resume/static/media/FiraSans-Regular.d95cbc6b.otf"
  },
  {
    "revision": "2de4568e043c3d69ca745f195c646440",
    "url": "/resume/static/media/FiraSans-SemiBold.2de4568e.otf"
  },
  {
    "revision": "782a2d18b0ed2cf85eb347659b2b5967",
    "url": "/resume/static/media/upwork_profile.782a2d18.png"
  }
]);